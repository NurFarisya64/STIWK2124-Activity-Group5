package com.example.musicbackend.controller;

import com.example.musicbackend.dto.LoginRequest;
import com.example.musicbackend.dto.LoginResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        String username = request.getUsername();
        String password = request.getPassword();

        if ("admin".equals(username) && "admin123".equals(password)) {
            return ResponseEntity.ok(new LoginResponse(username, "ADMIN"));
        }

        if ("user".equals(username) && "user123".equals(password)) {
            return ResponseEntity.ok(new LoginResponse(username, "USER"));
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
    }
}
