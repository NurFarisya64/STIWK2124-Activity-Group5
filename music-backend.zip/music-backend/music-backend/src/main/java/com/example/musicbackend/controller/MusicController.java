package com.example.musicbackend.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.musicbackend.model.Music;
import com.example.musicbackend.repository.MusicRepository;

@RestController
@RequestMapping("/api/music")
@CrossOrigin(origins = "http://localhost:4200")
public class MusicController {

    private final MusicRepository musicRepository;

    public MusicController(MusicRepository musicRepository) {
        this.musicRepository = musicRepository;
    }

    @GetMapping
    public List<Music> getAllMusic() {
        return musicRepository.findAll();
    }

    @GetMapping("/search")
public List<Music> searchMusic(@RequestParam String title) {
    return musicRepository.findByTitleContainingIgnoreCase(title);
}

    @PostMapping
    public Music addMusic(@RequestBody Music music) {
        return musicRepository.save(music);
    }

    @DeleteMapping("/{id}")
    public void deleteMusic(@PathVariable Long id) {
        musicRepository.deleteById(id);
    }

    @PutMapping("/{id}")
public Music updateMusic(@PathVariable Long id,
                         @RequestBody Music updatedMusic) {

    Music music = musicRepository.findById(id)
            .orElseThrow();

    music.setTitle(updatedMusic.getTitle());
    music.setArtist(updatedMusic.getArtist());
    music.setYoutubeLink(updatedMusic.getYoutubeLink());

    return musicRepository.save(music);
}
}
