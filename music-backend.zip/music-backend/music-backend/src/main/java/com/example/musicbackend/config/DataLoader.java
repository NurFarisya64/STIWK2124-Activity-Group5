package com.example.musicbackend.config;

import com.example.musicbackend.model.Music;
import com.example.musicbackend.repository.MusicRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadData(MusicRepository musicRepository) {
        return args -> {
            if (musicRepository.count() == 0) {
                musicRepository.save(new Music("Cruel Summer", "Taylor Swift", "https://www.youtube.com/watch?v=ic8j13piAhQ"));
                musicRepository.save(new Music("Perfect", "Ed Sheeran", "https://www.youtube.com/watch?v=2Vv-BfVoq4g"));
                musicRepository.save(new Music("Happier", "Olivia Rodrigo", "https://www.youtube.com/watch?v=ZQFmRXgeR-s"));
            }
        };
    }
}
