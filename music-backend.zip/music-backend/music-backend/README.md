# TuneManager Backend

This is a Spring Boot backend for the TuneManager music library frontend.

## Login Accounts

Admin:
- username: admin
- password: admin123

User:
- username: user
- password: user123

## API Endpoints

- POST http://localhost:8080/api/auth/login
- GET http://localhost:8080/api/music
- POST http://localhost:8080/api/music
- DELETE http://localhost:8080/api/music/{id}

## Run

```bash
mvn spring-boot:run
```
